*** Settings ***
Library    QWeb

Documentation           New test suite
# You can change imported library to "QWeb" if testing generic web application, not Salesforce.
Library                 QForce 
Suite Setup             Open Browser    about:blank    chrome
Suite Teardown          Close All Browsers

*** Test Cases ***

add product

    GoTo    https://www.amazon.in/
    ClickItem    Refrigerators
    ClickText    Add to cart    anchor=All
    ClickText    Add to cart    anchor=All
    ClickItem    Increase quantity by one
    ClickText    Add to cart    anchor=Eligible for Free Shipping
    VerifyText    ₹62,490 M.R.P: ₹1,09,390M.R.P: ₹1,09,390 (43% off)\nSave extra with No Cost EMISave extra with No Cost EMI\nFREE delivery as soon as Wed, 3 Jun, 7 am - 9 pm\nService: Brand Installation\nAdd to cart
    ClickText    Go to Cart
    ClickText    Proceed to checkout
    TypeText    email    65726236326
    ClickText    Continue
    [Documentation]    Test Case created using the QEditor

flow
    [Documentation]   Test Case created using the QEditor
    GoTo              https://www.google.com/search?q\=htttps%3A%2F%2Fsaucedemo.com&oq\=htttps%3A%2F%2Fsaucedemo.com&gs_lcrp\=EgZjaHJvbWUyBggAEEUYOTIGCAEQRRg60gEJMzI4MDJqMGoyqAIAsAIB&sourceid\=chrome&ie\=UTF-8
    CloseWindow
    VerifyText        \n
    ClickElement      /html[1]/body[1]/div[1]/div[1]/a[1]
    test

istqb_com

    GoTo    https://www.istqb.com/
    ClickText    Certifications
    ClickText    What is ISTQB Certification?
    ClickText    What is ISTQB Certification?    anchor=Table of Contents
    ClickText    Taking on Leadership Roles
    ClickText    Contact Us    anchor=News & Updates
    ClickElement    /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[1]/label[1]
    TypeText    Name (*)    archana
    ClickElement    /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[2]/label[1]
    TypeText    Email (*)    archana@gmail.com
    ClickElement    /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[3]/label[1]
    TypeText    Subject (*)    2
    ClickElement    /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[4]/label[1]
    TypeText    /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[4]/label[1]/span[1]/textarea[1]    test
    ClickText    Contact us    anchor=Fill this form to drop a line to us. We will reply to all reasonable questions/requests.
    ClickElement    /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[4]/label[1]
    TypeText    /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[4]/label[1]/span[1]/textarea[1]    test 123
    ClickText    Contact us    anchor=Fill this form to drop a line to us. We will reply to all reasonable questions/requests.
    [Documentation]    Test Case created using the QEditor

ISTQB_FLOW
    [Documentation]   Test Case created using the QEditor
    GoTo              https://www.istqb.com/
    ClickText         Contact Us        anchor=News & Updates
    ClickElement      /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[1]/label[1]
    TypeText          Name (*)          archana
    ClickElement      /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[2]/label[1]
    TypeText          Email (*)         archana@gmail.com
    ClickElement      /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[3]/label[1]
    TypeText          Subject (*)       QA
    ClickElement      /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[4]/label[1]
    TypeText          /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[4]/label[1]/span[1]/textarea[1]   ISTQB certification
    ClickText         Contact us        anchor=Fill this form to drop a line to us. We will reply to all reasonable questions/requests.
    ClickElement      /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[4]/label[1]
    VerifyText        ISTQB certification
    ClickElement      /html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/main[1]/article[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/p[4]/label[1]
    ClickText         Log in            anchor=Fill this form to drop a line to us. We will reply to all reasonable questions/requests.

flow mode istqb

    GoTo    https://www.istqb.com/
    ClickText    Study Materials    partial_match=False
    ClickText    here
    SwitchWindow    NEW
    SwitchWindow    2
    TypeText    Search this website    istqb\n    anchor=Primary Sidebar
    ClickText    about ISTQB® Certifications: Complete List of Active Exams (2026)
    [Documentation]   Test Case created using the QEditor
    GoTo              https://www.istqb.com/
    ClickText         Exam Boards
    TypeText          Search this website   American software testing qualification\n     anchor=Primary Sidebar
    ClickText         about ISTQB® CT-GenAI Certification: Complete Guide to Testing with Generative AI (2026)


*** Keywords ***

test
    [Documentation]    Block created using the QEditor


